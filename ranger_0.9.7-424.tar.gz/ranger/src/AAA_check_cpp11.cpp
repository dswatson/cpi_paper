#ifndef WIN_R_BUILD
#if __cplusplus < 201103L
#error Error: ranger requires a real C++11 compiler, e.g., gcc >= 4.7 or Clang >= 3.0. You probably have to update your C++ compiler.
#endif
#endif

